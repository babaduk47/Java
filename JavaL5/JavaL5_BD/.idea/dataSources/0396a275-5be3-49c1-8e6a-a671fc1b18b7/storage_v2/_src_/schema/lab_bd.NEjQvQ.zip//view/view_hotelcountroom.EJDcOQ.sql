create definer = root@localhost view view_hotelcountroom as
select `h`.`Name` AS `Отель`, count(`hr`.`room_number`) AS `Количество свободных комнат`
from `lab_bd`.`hotel-rooms` `hr`
         join `lab_bd`.`hotel` `h`
where `hr`.`id_hotel` = `h`.`ID`
  and `hr`.`isavailable` = 1
group by `h`.`Name`
having count(`hr`.`room_number`) > 1;

