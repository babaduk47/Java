create definer = root@localhost view view_hotel as
select `lab_bd`.`hotel`.`ID`         AS `ID`,
       `lab_bd`.`hotel`.`Name`       AS `Name`,
       `lab_bd`.`hotel`.`CountFloor` AS `CountFloor`,
       `lab_bd`.`hotel`.`Stars`      AS `Stars`
from `lab_bd`.`hotel`;

