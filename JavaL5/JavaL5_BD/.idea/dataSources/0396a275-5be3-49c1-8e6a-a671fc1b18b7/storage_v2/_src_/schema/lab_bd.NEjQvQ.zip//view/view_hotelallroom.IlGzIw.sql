create definer = root@localhost view view_hotelallroom as
select `h`.`Name`                                           AS `Отель`,
       (select count(`lab_bd`.`hotel-rooms`.`room_number`)
        from `lab_bd`.`hotel-rooms`
        where `lab_bd`.`hotel-rooms`.`id_hotel` = `h`.`ID`) AS `Всего комнат`
from `lab_bd`.`hotel-rooms` `hr`
         join `lab_bd`.`hotel` `h`
group by `h`.`Name`;

