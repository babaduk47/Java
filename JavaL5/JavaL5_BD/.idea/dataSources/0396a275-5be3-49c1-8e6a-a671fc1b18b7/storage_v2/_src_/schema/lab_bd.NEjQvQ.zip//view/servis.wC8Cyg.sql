create definer = root@localhost view servis as
select `lab_bd`.`services`.`id_servis` AS `id_servis`, `lab_bd`.`services`.`name_servis` AS `name_servis`
from `lab_bd`.`services`;

