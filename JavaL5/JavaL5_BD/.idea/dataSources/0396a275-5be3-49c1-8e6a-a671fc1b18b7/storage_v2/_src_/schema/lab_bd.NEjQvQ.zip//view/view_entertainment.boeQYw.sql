create definer = root@localhost view view_entertainment as
select `lab_bd`.`entertainment`.`id_entertainment`   AS `id_entertainment`,
       `lab_bd`.`entertainment`.`name_entertainment` AS `name_entertainment`
from `lab_bd`.`entertainment`;

