create definer = root@localhost view view_servis_entertainment as
select `lab_bd`.`services`.`name_servis` AS `Сервисы и развлечения`, `lab_bd`.`services`.`price_servis` AS `Цена`
from `lab_bd`.`services`
union
select `lab_bd`.`entertainment`.`name_entertainment`  AS `name_entertainment`,
       `lab_bd`.`entertainment`.`price_entertainment` AS `price_entertainment`
from `lab_bd`.`entertainment`;

